# StoreCraft Studio website

A responsive, static website starter for a Shopify store development agency.

## Included
- Responsive homepage with mobile navigation
- Service descriptions, process, concept work examples, FAQs and quote form
- SEO title and meta description
- Open Graph tags, canonical placeholder, and JSON-LD ProfessionalService schema
- No build step required

## Before publishing
1. Buy a domain and connect it to a hosting provider (for example, Netlify, Cloudflare Pages, GitHub Pages, or your own hosting).
2. Replace `YOUR-DOMAIN.com` in `index.html` with your real domain (canonical URL, Open Graph URL/image, and JSON-LD URL).
3. Replace `YOUR-EMAIL@example.com` in `script.js` with your business email. The form currently opens the visitor's email app; it does not store submissions. For a proper lead form, connect a form service or backend.
4. Add your real portfolio, genuine testimonials, business details, privacy policy, and terms. Do not publish invented client reviews or claims.
5. Add a real `og-image.jpg` and optional favicon/social assets if desired.
6. After launch, verify the domain in Google Search Console, submit your sitemap, and request indexing. Rankings are not guaranteed and may take time.

## SEO notes
- Create separate, useful service pages as the business grows (for example `/shopify-store-development/`, `/shopify-store-redesign/`, and `/shopify-theme-customization/`).
- Write original copy for your target markets and add only truthful case studies.
- A sitemap and robots.txt should be updated with your real domain before submission.
