const menuButton = document.querySelector('.menu-toggle');
const nav = document.querySelector('.nav');
menuButton?.addEventListener('click', () => {
  const isOpen = nav.classList.toggle('open');
  menuButton.setAttribute('aria-expanded', String(isOpen));
  menuButton.setAttribute('aria-label', isOpen ? 'Close menu' : 'Open menu');
  menuButton.textContent = isOpen ? '×' : '☰';
});
nav?.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
  nav.classList.remove('open');
  menuButton?.setAttribute('aria-expanded', 'false');
  if (menuButton) { menuButton.textContent = '☰'; menuButton.setAttribute('aria-label', 'Open menu'); }
}));
document.getElementById('year').textContent = new Date().getFullYear();

const form = document.getElementById('quote-form');
form?.addEventListener('submit', (event) => {
  event.preventDefault();
  const data = new FormData(form);
  const subject = encodeURIComponent('Shopify project inquiry — ' + data.get('name'));
  const body = encodeURIComponent(
`Name: ${data.get('name')}
Email: ${data.get('email')}
Service: ${data.get('project')}
Budget: ${data.get('budget') || 'Not specified'}

Project details:
${data.get('details')}`
  );
  // Replace this placeholder with your real business email before publishing.
  const businessEmail = 'YOUR-EMAIL@example.com';
  const status = document.getElementById('form-status');
  if (businessEmail === 'YOUR-EMAIL@example.com') {
    status.textContent = 'Setup needed: replace YOUR-EMAIL@example.com in script.js with your business email before publishing.';
    return;
  }
  status.textContent = 'Opening your email app to send the inquiry…';
  window.location.href = `mailto:${businessEmail}?subject=${subject}&body=${body}`;
});
